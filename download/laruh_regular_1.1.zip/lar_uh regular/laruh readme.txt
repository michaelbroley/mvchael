

$$\        $$$$$$\  $$$$$$$\        $$\   $$\ $$\   $$\       $$$$$$$\  $$$$$$$$\  $$$$$$\  $$\   $$\ $$\        $$$$$$\  $$$$$$$\  
$$ |      $$  __$$\ $$  __$$\       $$ |  $$ |$$ |  $$ |      $$  __$$\ $$  _____|$$  __$$\ $$ |  $$ |$$ |      $$  __$$\ $$  __$$\ 
$$ |      $$ /  $$ |$$ |  $$ |      $$ |  $$ |$$ |  $$ |      $$ |  $$ |$$ |      $$ /  \__|$$ |  $$ |$$ |      $$ /  $$ |$$ |  $$ |
$$ |      $$$$$$$$ |$$$$$$$  |      $$ |  $$ |$$$$$$$$ |      $$$$$$$  |$$$$$\    $$ |$$$$\ $$ |  $$ |$$ |      $$$$$$$$ |$$$$$$$  |
$$ |      $$  __$$ |$$  __$$<       $$ |  $$ |$$  __$$ |      $$  __$$< $$  __|   $$ |\_$$ |$$ |  $$ |$$ |      $$  __$$ |$$  __$$< 
$$ |      $$ |  $$ |$$ |  $$ |      $$ |  $$ |$$ |  $$ |      $$ |  $$ |$$ |      $$ |  $$ |$$ |  $$ |$$ |      $$ |  $$ |$$ |  $$ |
$$$$$$$$\ $$ |  $$ |$$ |  $$ |      \$$$$$$  |$$ |  $$ |      $$ |  $$ |$$$$$$$$\ \$$$$$$  |\$$$$$$  |$$$$$$$$\ $$ |  $$ |$$ |  $$ |
\________|\__|  \__|\__|  \__|$$$\\______/ \__|  \__|      \__|  \__|\________| \______/  \______/ \________|\__|  \__|\__|  \__|
                              \___|                                                                                                                                                   
                                                                                                                                                                                                                                                                                                                                                                                                   

First of All,

Thank you for downloading our collaboration.

This font is free for personal use.

This font may not be used for commercial purposes without written consent from Lara Anderson.

This font may not be shared, hosted or redistributed.

Thank you,

Lara & Mike


////////////////////////////////////////


More Font Info : 
mvchael.com/random-free-font-laruh-regular.html

My Portofolio:
www.mvchael.com

Lara's Portfolio:
laruh.ca


////////////////////////////////////////


File include : 

1. laruh regular.ttf
2. laruh readme.txt
3. laruh banner.jpg


////////////////////////////////////////